# QA Hackathon Spreadsheet Report — AI Bracket War Room 2026

Generated: 2026-06-06

## Artifact

| Field | Value |
|---|---|
| File | `FIX6C_STATIC_ANNEXC_HACKATHON_READY.xlsx` |
| Size | `54,509 bytes` |
| SHA256 | `ee73e74fb7e08cde04132d08000ace99a2b89b3a31ea6e6aec31b5f47089cc62` |
| Source | `FIX6C_STATIC_ANNEXC.xlsx` |
| Google Sheets demo link | `https://docs.google.com/spreadsheets/d/1dptWAJhyu-ggGoIjOiKo7Fh4hQYs1l6oF7RYLAyFj_0/edit?usp=sharing` |

## Sheet inventory

| Sheet | Status | Hackathon role |
|---|---|---|
| `START_HERE` | visible | Demo navigation + product story |
| `BRACKET_WAR_ROOM` | visible | Command-center proof sheet |
| `MATCH_PLANNER` | visible | 104-match editable planner |
| `FRIENDS_LEAGUE` | visible | Private league scoreboard |
| `AnnexC_495_STATIC` | visible | 495-record static data layer |
| `QA_STATIC_CHECK` | visible / can be hidden manually in Google Sheets | Internal QA proof sheet |

## Coverage QA

| Check | Expected | Actual | Result |
|---|---:|---:|---|
| Workbook sheets | 6 | 6 | PASS |
| `MATCH_PLANNER` match rows | 104 | 104 | PASS |
| Match ID range | `M001–M104` | `M001–M104` | PASS |
| Annex C records | 495 | 495 | PASS |
| Formula count | > 0 | 140 | PASS |
| Internal navigation formulas | > 0 | 16 | PASS |
| Formula error tokens inside formulas | 0 | 0 | PASS |

## Patched functionality

### `MATCH_PLANNER`

- Expanded from 24 visible match rows to 104 rows.
- Columns now use:

```text
A Match ID
B Phase
C Side A
D Side B
E Prediction
F AI Signal
G Confidence %
H Watch Priority
I Notes
J Result
K Points
```

- Phase mapping:

```text
M001–M072 = Group Stage
M073–M088 = Round of 32
M089–M096 = Round of 16
M097–M100 = Quarterfinal
M101–M102 = Semifinal
M103 = Third Place
M104 = Final
```

- Points formula in `K6:K109`:

```excel
=IF(J6="","",IF(E6=J6,3,0))
```

### `FRIENDS_LEAGUE`

- Expanded to 20 player rows.
- Added formula-driven Total Points in `F6:F25`:

```excel
=IF(A6="","",C6*3+D6*1+E6*2)
```

### Navigation / relinking

Internal navigation formulas added with `HYPERLINK()` on:

- `START_HERE`
- `BRACKET_WAR_ROOM`
- `MATCH_PLANNER`
- `FRIENDS_LEAGUE`
- `AnnexC_495_STATIC`

Note: the local artifact renderer does not compute `HYPERLINK()` visual labels, but Excel / Google Sheets should recalculate the formulas after opening/import. If Google Sheets conversion does not preserve internal workbook targets, keep the visible sheet tabs and `START_HERE` instructions as fallback navigation.

## Claim-control QA

Use these hackathon-safe claims:

```text
static spreadsheet engine
Google Sheets demo version
Excel-compatible XLSX source
offline editable tournament tracker
104-match planning grid
private friends-league scoring
495-record static Annex C data layer
```

Do not claim:

```text
live Google Sheets automation
real-time web imports
official tournament data feed
FIFA affiliation
sportsbook odds
betting engine
```

## Manual cloud QA required after upload

Because the live Google Sheet cannot be modified from this environment, perform these checks after replacing the current Google Sheet with this XLSX:

1. Upload/import `FIX6C_STATIC_ANNEXC_HACKATHON_READY.xlsx`.
2. Confirm sheets appear in this order:
   - `START_HERE`
   - `BRACKET_WAR_ROOM`
   - `MATCH_PLANNER`
   - `FRIENDS_LEAGUE`
   - `AnnexC_495_STATIC`
   - `QA_STATIC_CHECK`
3. Confirm `MATCH_PLANNER` has `M001–M104`.
4. Test at least one points formula:
   - Put the same value into `E6` and `J6`.
   - Confirm `K6 = 3`.
   - Clear `J6`.
   - Confirm `K6` becomes blank.
5. Test Friends League formula:
   - Set `C6=2`, `D6=5`, `E6=1`.
   - Confirm `F6 = 13`.
6. Click `START_HERE` navigation cells.
7. If desired, hide `QA_STATIC_CHECK` manually in Google Sheets.
8. Share as `Viewer`.
9. For judges, instruct: `File → Make a copy` before editing.

## Final status

`FIX6C_STATIC_ANNEXC_HACKATHON_READY.xlsx` is ready to hand to Codex for repository inclusion as the hackathon spreadsheet engine artifact.
